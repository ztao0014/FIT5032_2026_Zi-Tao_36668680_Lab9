// Alibaba Cloud Function Compute - HTTP Trigger
// No dependencies required - pure Node.js

const authors = [
  {
    name: "Jane Austen",
    birthYear: 1775,
    famousWorks: [
      { title: "Pride and Prejudice", year: 1813 },
      { title: "Sense and Sensibility", year: 1811 }
    ]
  },
  {
    name: "George Orwell",
    birthYear: 1903,
    famousWorks: [
      { title: "1984", year: 1949 },
      { title: "Animal Farm", year: 1945 }
    ]
  },
  {
    name: "Agatha Christie",
    birthYear: 1890,
    famousWorks: [
      { title: "Murder on the Orient Express", year: 1934 },
      { title: "Death on the Nile", year: 1937 }
    ]
  }
]

exports.handler = (req, resp) => {
  // CORS headers
  resp.setHeader('Access-Control-Allow-Origin', '*')
  resp.setHeader('Content-Type', 'application/json')

  if (req.method === 'GET' && req.path === '/countBooks') {
    const totalBooks = authors.reduce((total, author) =>
      total + author.famousWorks.length, 0
    )

    const result = {
      success: true,
      data: {
        authorsCount: authors.length,
        totalBooks: totalBooks,
        authors: authors.map(a => ({
          name: a.name,
          bookCount: a.famousWorks.length,
          works: a.famousWorks.map(w => w.title)
        }))
      },
      timestamp: new Date().toISOString()
    }

    resp.statusCode = 200
    resp.end(JSON.stringify(result, null, 2))
  } else {
    resp.statusCode = 200
    resp.end('Cloud Function is running! Visit /countBooks')
  }
}
